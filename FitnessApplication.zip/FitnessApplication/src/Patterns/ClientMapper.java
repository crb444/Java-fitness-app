package Patterns;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Business.FitnessGoal;
import Database.DBConnection;
import Objects.Client;

/**
 * 
 * @author Dhilan Chandrasekara, Chamira Balasuriya
 * 
 * Responsible for querying the database and returning Client instances, filled in with
 * information retrived from the database 
 *
 */
public class ClientMapper   {
	
	//Get it
	
	@Override
	public String toString() {
		return "This is the Client Mapper toString() method";
	}
	
	public static ArrayList<Client> getAllClients() {
    	ArrayList<Client> clients = new ArrayList<>();
		try {
			PreparedStatement stmt = DBConnection.prepare("SELECT * FROM client");
			ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				Client client = getClientInstanceFromResultSet(rs);
				//System.out.println(client.getLastName());
				
				clients.add(client);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return clients;
	}
	
	public static Client getClientFromId(int id) {
		Client client = new Client();
		try {
			PreparedStatement stmt = DBConnection.prepare("SELECT * FROM client WHERE memberid=" +
					Integer.toString(id) + ";");
			ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				System.out.println("rs next was true once");
				try {
				System.out.println("getClientFromId() method: Client name is" + rs.getString(2));
				} catch (NullPointerException e) {
					System.out.println("Null pointer exception :( ");
				}
				
				client.setClientId(id);
				client.setFirstName(rs.getString(2));
				client.setLastName(rs.getString(3));
				client.setContactNumber(rs.getString(4));
				client.setGoal(FitnessGoal.WEIGHTLOSS); //TODO: Change to reflect DB
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return client;
	}
	
	public static Client getClientInstanceFromResultSet(ResultSet rs) throws SQLException {
		Client client = new Client();
		client.setClientId(rs.getInt(1));
		client.setFirstName(rs.getString(2));
		client.setLastName(rs.getString(3));
		client.setContactNumber(rs.getString(4));
		client.setGoal(FitnessGoal.WEIGHTLOSS); //TODO: Change to reflect DB
		
		return client;
	}
	
	public static void removeClientById(int id) {
		try {
			PreparedStatement s = DBConnection.prepare("DELETE FROM client WHERE memberid=" +
			Integer.toString(id) + ";COMMIT;");
			s.executeUpdate();}
		catch (Exception e) {
			e.printStackTrace();
		}

	}
}
