package Patterns;
import java.util.ArrayList;
import Objects.Client;
import Objects.ClientManagementServlet;

public class ClientDataServiceLayer {
	
	ArrayList<Client> clients;
	UnitOfWork uow;
	IdentityMap im;
	
	public ClientDataServiceLayer() {
		ClientManagementServlet.clientDataServiceLayer = this;
		clients = ClientMapper.getAllClients();
		im = new IdentityMap();
		uow = new UnitOfWork();
		for (Client c : clients) {
			uow.registerAsNew(c);
			im.put(c.getClientId(),c);
			ClientManagementServlet.clientIds.add(c.getClientId());
		}
		
	}
	
	
	public String displayAllClientsAsList() {
		String result = "<ul>";
		for (Client c : clients) {
			result = result + c.getFirstName() + " " + c.getLastName() + " <input type=\"submit\" name=\"" + c.getClientId() + "\" value=\"Remove\" />"
					+ " <input type=\"submit\" name=\"" + c.getClientId() + "WORKOUT" + "\" value=\"Add Workout\" />" + "<br>";
		}
		return result + "</ul>";
	}
	
	public void conductClientRemoval(int id) {
		Client client = new Client();
		for (Client c : clients) {
			if (c.getClientId() == id) {
				client = c;
				break;
			}
		}
		uow.registerDelete(client);
		im.remove(id);
		uow.commitChanges();
		System.out.println("CDSL conduct client removal method has executed");
	}
}
