package Patterns;

import java.util.ArrayList;
import Business.Workout;
import Objects.Client;

public class UnitOfWork {
	private static ThreadLocal current = new ThreadLocal(); 
	
	private static ArrayList<Object> newObjects = new ArrayList<Object>(); 
	private static ArrayList<Object> dirtyObjects = new ArrayList<Object>();
	private static ArrayList<Object> deletedObjects = new ArrayList<Object>();  
	
	private static IdentityMap identMap = new IdentityMap(); 
	
	public void registerDelete(Object o) {
		if (newObjects.contains(o)) {
			newObjects.remove(o);
		}
		if (dirtyObjects.contains(o)) {
			dirtyObjects.remove(o);
		}
		deletedObjects.add(o);
		
	}
	
	public static void newCurrent() {
		setCurrent(new UnitOfWork()); 
	
	}
	
	public static void setCurrent(UnitOfWork uow) {
		current.set(uow);
	}
	
	public static UnitOfWork getCurrent() {
		return (UnitOfWork) current.get();
	}
	
	public static void registerAsNew(Object obj) {  
		//check if obj is in the identity map 
		obj = findSingleton(obj, getIdentityMap() );
		if(!newObjects.contains(obj) && !dirtyObjects.contains(obj) && !deletedObjects.contains(obj)) {
		newObjects.add(obj); 
		}
	}
	
	public static void registerAsDirty(Object obj) { 
		//check if obj is in identity map 
		obj = findSingleton(obj, getIdentityMap() );
		if(deletedObjects.contains(obj)) {
			System.out.print("Cannot modify deleted object");
		} else if (dirtyObjects.contains(obj)) {
			System.out.print("Already in modified list");
		} else {
			dirtyObjects.add(obj);
			newObjects.remove(obj);
		}
	}
	
	public static void registerAsDeleted(Object obj) {
		//check if obj is in identity map 
		obj = findSingleton(obj, getIdentityMap() );
		if(deletedObjects.contains(obj)) {
			System.out.print("Already in deleted list");
		} else {
			deletedObjects.add(obj); 
		}
	}  
	
	
	
	//identity map pattern 
	public static Object findSingleton(Object obj, IdentityMap identMap) {
		Class c = obj.getClass(); 
		
		
		if(obj.getClass().getName().equalsIgnoreCase("Workout")) { 
			Workout wo = new Workout();
			wo = (Workout) obj;    
			int id = wo.getId(); 
			identMap = IdentityMap.getInstance(wo); 
			wo = (Workout) identMap.get(id);  
			
			if(wo == null) {
				Workout woNew = new Workout();
				//get from database , with the result, save each parameter 
				/*woNew.setId(record.getId()); 
				woNew.setName(record.getName());
				woNew.setTargetMuscleGroup(record.getTargetMuscleGroup());
				woNew.setExercises(record.getExercises()); */
				//delete above
				identMap.put(id, woNew); 
				return woNew;
			} else {
				return wo; 
			}
		
		} else if(obj.getClass().getName().equalsIgnoreCase("Client"))  {
			Client cl = new Client();
			cl = (Client) obj;    
			int id = cl.getClientId(); 
			identMap = IdentityMap.getInstance(cl); 
			cl = (Client) identMap.get(id);  
			
			if(c == null) {
				Client cNew = new Client();
				//get from database/
	/*
				rs = RESULT
				cNew.setClientId(id);
				cNew.setTrainerId();
				cNew.setFirstName();
				cNew.setLastName();
				cNew.setContactNumber();
				cNew.setGoal(goal); */
				//delete above
				identMap.put(id, cNew); 
				return cNew; 
			} else {
				return c; 
			}
		} 
		return new Object();
		
		
	}
	
	public static IdentityMap getIdentityMap() {
		return identMap; 
	}
	
	public static void commitChanges() { 
		for (Object o : deletedObjects) {
			if (o instanceof Client) {
				Client client = (Client)o;
				int id = client.getClientId();
				ClientMapper.removeClientById(id);
			}
		}
		// ADD DATABASE insert, modify, delete 
	}
}
