package Patterns;

import java.util.ArrayList;

import Business.Exercise;

public class ExerciseDataServiceLayer {
	public String populateDropDownWithAllExercises() {
		ArrayList<Exercise> exercises = ExerciseMapper.getAllExercises();
		String result = "";
		
		for (Exercise e : exercises) {
			result = result + "<option>" + e.getName() + "</option>";
		}
		
		return result;
	}
}
