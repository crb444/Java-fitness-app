package Authentication;

import java.util.ArrayList;

public class DummyClass {
	
	ArrayList<String> xx;
	
	@Override
	public String toString() {
		return "this is the toString() method of the dummy class";
	}
	
	public DummyClass() {
		xx.add("usain");
		xx.add("bolt");
		xx.add("justin");
		xx.add("gatlin");
	}
}
