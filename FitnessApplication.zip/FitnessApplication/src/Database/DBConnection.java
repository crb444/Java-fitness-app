package Database;

import java.net.URI;
import java.net.URISyntaxException;
import java.sql.*;


public class DBConnection {
	
	// JDBC driver name and database URL
	
	private static final String DB_CONNECTION = "jdbc:postgresql://ec2-54-83-33-14.compute-1.amazonaws.com:5432/d7gcv8i5opq0t9?sslmode=require&user=ystpwvxtztpnap&password=73c82b66bdbc2edb309a69b7698c9942e3d2842b301cff627501810be3feaa08";
	
	// Database credentials
	
	private static final String DB_USER = "dchandraseka@student.unimelb.edu.au";
	private static final String DB_PASSWORD = "MelloTrr";
	
	static Connection dbConnection = null;
	
	private static Connection geturiConnection() throws URISyntaxException, SQLException {
	    URI dbUri = new URI(System.getenv("postgres://ystpwvxtztpnap:73c82b66bdbc2edb309a69b7698c9942e3d2842b301cff627501810be3feaa08@ec2-54-83-33-14.compute-1.amazonaws.com:5432/d7gcv8i5opq0t9"
));

	    String username = dbUri.getUserInfo().split(":")[0];
	    String password = dbUri.getUserInfo().split(":")[1];
	    String dbUrl = "jdbc:postgresql://" + dbUri.getHost() + ':' + dbUri.getPort() + dbUri.getPath();

	    return DriverManager.getConnection(dbUrl, username, password);
	}
	
	private static Connection getConnection() throws URISyntaxException, SQLException {
		DriverManager.registerDriver(new org.postgresql.Driver());
		String dbUrl = System.getenv(DB_CONNECTION);
	    return DriverManager.getConnection(dbUrl);
	}
	
	public static PreparedStatement prepare(String stm) throws SQLException {
		PreparedStatement preparedStatement = null;
		try {
			dbConnection = geturiConnection();
			preparedStatement = dbConnection.prepareStatement(stm);
			
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return preparedStatement;
	}
	
	
	public static void delete2() {
		PreparedStatement preparedStatement = null;
		try {
			
			preparedStatement = dbConnection.prepareStatement("DELETE from client WHERE memberID=112;");
			preparedStatement.execute();
			
			
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		
	}
	
	/**
	 * 
	 * 'value' parameter needs wrapping quotes if it refers to a String in the database
	 */
	public static void deleteQuery(String table, String column, String value) {
		
		String SQLQuery = "DELETE FROM client WHERE memberID=112";
		System.out.println("THE SSQL QUWETY IS " + SQLQuery );
		
		try (Connection dbConnection = getDBConnection();
				Statement stmt = dbConnection.createStatement();) {
			
			stmt.executeUpdate(SQLQuery);
			System.out.println("end of record delete try block");
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	
	private static Connection getDBConnection() {
		try {
			// Register JBDC driver
			DriverManager.registerDriver(new org.postgresql.Driver());
			
			// Open a connection
			dbConnection = DriverManager.getConnection(DB_CONNECTION, 
					DB_USER, DB_PASSWORD);
			dbConnection.setAutoCommit(false);
			
			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Connection problem");
		return null;
	}

}
