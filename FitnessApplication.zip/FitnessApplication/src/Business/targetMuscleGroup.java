package Business;

public enum targetMuscleGroup {
		CHEST, ARMS, LEGS, SHOULDERS, BACK 
}
