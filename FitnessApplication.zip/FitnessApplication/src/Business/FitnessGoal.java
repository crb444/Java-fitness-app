package Business;

public enum FitnessGoal {

		WEIGHTLOSS,
		MUSCLEBUILDING,
		COMPETITION, 
	
}
