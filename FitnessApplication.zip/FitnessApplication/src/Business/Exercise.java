package Business;

import Patterns.Record; 
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Patterns.IdentityMap;


public class Exercise { 
	private int exerciseId; 
	private String name; 
	private String targetMuscle;
	private targetMuscleGroup targetMuscleGroup; 
	private int repititions; 
	
	// ADD TARGET MUSCLE GROUP INTO SETTERS AND GETTERS
	
	public Exercise() {
		
	}
	
	public Exercise(int exerciseId, String name, String targetMuscle, int repititions) {
		this.name = name; 
		this.targetMuscle = targetMuscle; 
		this.repititions = repititions; 
		finder(exerciseId);  
	}  
	
//	//identity map pattern 
//	public Exercise finderSingleton(int id) {
//		Exercise ex = new Exercise(); 
//		IdentityMap<Exercise> map = IdentityMap.getInstance(ex); 
//		ex = map.get(id); 
//		
//		if(ex == null) {
//			Exercise ex2 = new Exercise();
//			Record record = new Record(gateway.find(id));  
//			ex2.setId(record.getId()); 
//			ex2.setName(record.getName());
//			ex2.setTargetMuscle(record.getTargetMuscle());
//			ex2.setTargetMuscleGroup(record.getTargetMuscleGroup());
//			map.put(id, ex2);	
//			return ex2;
//		} else {
//			return ex; 
//		}
//	}
	
	//identity field pattern
	public void finder(int exerciseId) {
		String sql = "SELECT id FROM exercise WHERE name=" + getName() + " AND targetMuscleGroup=" + getTargetMuscleGroup(); 
		PreparedStatement stmt = DBConnection.prepare(sql);
		try {
			ResultSet rs = stmt.executeQuery(); 
			if(rs != null) {
				int dbId = rs.getInt(1);
				this.exerciseId = dbId; 
			} else {
				this.exerciseId = exerciseId;  
			}
		} catch (SQLException e) {
			System.out.println(e); 
		}
	} 
	
	public int getExerciseId() {
		return exerciseId; 
	} 
	
	
	
	public String getTargetMuscle() { 
		if(this.targetMuscle == null) {
			Exercise ex = gateway.find(this.id); 
			this.targetMuscle = ex.getTargetMuscle(); 
		}
		return targetMuscle; 
	}
	
	public int getRepititions() { 
		if(this.repititions == 0) {
			Exercise ex = gateway.find(this.id); 
			this.repititions = ex.getRepititions(); 
		}
		return repititions; 
	}
	
	public int getID() {
		return exerciseId; 
	} 
	
	public String getName() {
		return name;
	}
	
	public targetMuscleGroup getTargetMuscleGroup() {
		return targetMuscleGroup; 
	}
	
	public void setId(int id) {
		this.exerciseId = id; 
	} 
	
	public void setName(String name) {
		this.name = name; 
	} 
	
	public void setTargetMuscle(String targetMuscle) {
		this.targetMuscle = targetMuscle; 
	} 
	
	public void setTargetMuscleGroup(targetMuscleGroup tmg) {
		this.targetMuscleGroup = tmg; 
	} 
	
	public void setRepititions(int rep) {
		this.repititions = rep; 
	}

}
