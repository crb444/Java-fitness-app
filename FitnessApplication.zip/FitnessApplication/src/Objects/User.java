package Objects;

public abstract class User {

}
